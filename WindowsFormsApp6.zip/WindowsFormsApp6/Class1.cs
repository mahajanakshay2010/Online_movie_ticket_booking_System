﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    internal class Class1
    {

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Akshay Mahajan\Documents\localDB.mdf;Integrated Security=True;Connect Timeout=300");
        SqlCommand cmd;
        SqlCommandBuilder bld;
        SqlDataAdapter adpt;
        DataTable dt;
        DataTable dt2;
       
        public DataTable topMovies()
        {
            String qry = "select * from Movie";
            con.Open();
            adpt = new SqlDataAdapter(qry, con);
            bld = new SqlCommandBuilder(adpt);
            dt = new DataTable();
            adpt.Fill(dt);
            con.Close();
            return dt;
        }
        public int add_data(String MovieName,int Price)
        {
            
            String qry = "Insert into Movie values('" + MovieName + "'," + Price + ")";
            con.Open();
            cmd = new SqlCommand(qry, con);
            int no = cmd.ExecuteNonQuery();
            con.Close();
            return no;
            
        }

        public DataTable upcommingMovies()
        {
            String qry = "select * from UpcommingMovies";
            con.Open();
            adpt = new SqlDataAdapter(qry, con);
            bld = new SqlCommandBuilder(adpt);
            dt2 = new DataTable();
            adpt.Fill(dt2);
            con.Close();
            return dt2;
        }

        public int addUpcommingMovies(String MovieName)
        {
            String qry = "Insert into UpcommingMovies values('" + MovieName + "')";
            con.Open();
            cmd = new SqlCommand(qry, con);
            int no = cmd.ExecuteNonQuery();
            con.Close();
            return no;

        }
        

    }
}

